package com.lsscl.app.dao;

import com.lsscl.app.bean.QC;
import com.lsscl.app.bean.RSP;

public class AppDaoImpl extends AppDao {

	@Override
	public RSP getRSP(QC qc) {
		// TODO Auto-generated method stub
		return null;
	}

}
